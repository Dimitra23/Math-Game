#import necessary libraries
from pygame.locals import *
import pygame_textinput
import pygame
from random import randrange
from random import randint
import os
import time

#import configuration file
#determines the difficulty of the game
from config import *

#initialize PyGame
pygame.init()

#Environment variables of the SDL library (the basis of PyGame) can be used to direct the Window manager
#center the game window on screen
os.environ['SDL_VIDEO_CENTERED'] = '1'

#dimensions of board tiles
TILE_WIDTH = 110
TILE_HEIGHT = 100
#space between tiles
TILE_MARGIN = 5
#space on top of the board for playing controls and messages
TOP_MARGIN = 100

#calculation of the screen width and height based on the board dimensions (from the configuration file)
SCREEN_WIDTH = COLUMNS*TILE_WIDTH + (COLUMNS + 1)*TILE_MARGIN
SCREEN_HEIGHT = ROWS*TILE_HEIGHT + (ROWS + 1)*TILE_MARGIN + TOP_MARGIN

#the PyGame clock
clock = pygame.time.Clock()

#initialize the game display
screen = pygame.display.set_mode([SCREEN_WIDTH, SCREEN_HEIGHT], 0, 32)

#tile images
#the tile is a possible next step
image_possible = pygame.image.load('assets/tile-possible.jpg')
#the tile is a possible future tile (not in the next step)
image_future = pygame.image.load('assets/tile-future.jpg')
#the current tile
image_current = pygame.image.load('assets/tile-current.jpg')
#special tile for the start
image_start = pygame.image.load('assets/start.jpg')
#special tile for the finish
image_finish = pygame.image.load('assets/finish.jpg')
#special tile for the finish when it is a possilbe next step
image_finishing = pygame.image.load('assets/finishing.jpg')
#special tile for the finish when the player has won (the finish tile is the current tile)
image_finished = pygame.image.load('assets/finished.jpg')
#horizontal wall image
image_wall_h = pygame.image.load('assets/wall-h.jpg')
#vertical wall image
image_wall_v = pygame.image.load('assets/wall-v.jpg')

#game title and icon
pygame.display.set_caption('Math shows the way!')
gameIcon = pygame.image.load('assets/icon.png')
pygame.display.set_icon(gameIcon)
#open file for results
global resultsFile

#Initialize game values (global variables)
global current_tile
global current_tile_x
global current_tile_y
#the potential next move
global potential_next_tile
global potential_next_tile_x
global potential_next_tile_y
#each time the player answers correctly, the number of steps he can take increases by one
#each time the player makes a mistake, the offset is decreased by 1 (minimum value = 1)
global current_offset
#array of possible future tiles (physical coordinates on board)
global future_tiles
#array of possible future tiles (matrix coordinates)
global future_tiles_coords
#is the game still in progress?
global game_state
#input box for the player answer
global inputBox1
#do we need to display an expression for evaluation?
global showMath
global expressionValue
#array for vertical walls erected when the player makes a mistake
global vertical_walls
vertical_walls = []
#array for horizontal walls erected when the player makes a mistake
global horizontal_walls
horizontal_walls = []
#no expression is displayed before the player chooses a next step
showMath = False

#initialization of the input box variable
inputBox1 = pygame_textinput.TextInput(initial_string="",repeat_keys_initial_ms=400,repeat_keys_interval_ms=400)

#current tile coordinates - current player position
#initially (0,0)
current_tile_x = 0
current_tile_y = 0
current_tile = (current_tile_x, current_tile_y)

#offset --> how many blocks can the player move forward
#offset increases with the number of consecutive correct answers
current_offset = 1

#future tiles --> potential next moves according to current tile and offset
#the future tiles list contains the left - right - top - bottom positions of the potential next moves
future_tiles = []
#the future tiles coords list contains the x,y coordinates of the future tiles
future_tiles_coords = []

#game in progress
game_state = 1

#auxiliary function for displaying text labels
def text_objects(text, font):
    textSurface = font.render(text, True, (0,0,0))
    return textSurface, textSurface.get_rect()

#function that displays a message on a given position
def display_message(text, pos):
    #rectangle that "erases" area
    pygame.draw.rect(screen, (200,200,200), [0, 0, 400, 40])
    #load custom font from file
    largeText = pygame.font.Font('C:\\Ubuntu-R.ttf',16)
    #call auxiliary function to initialize writing surface
    TextSurf, TextRect = text_objects(text, largeText)
    #place text on given position (function argument)
    TextRect.center = pos
    #place text on screen
    screen.blit(TextSurf, TextRect)

#function that return arithmetic expression + correct result
def mathExp():
    global expressionValue
    #array of operators that can be used in expression
    #addition is always allowed
    operators = ['+']
    #other arithmetic operations are enabled/ disabled via the config file
    if USE_SUBSTRACTION == True:
            operators.append('-')

    if USE_MULTIPLICATION == True:
            operators.append('*')

    if USE_DIVISION == True:
            operators.append('/')

    if USE_POWER == True:
            operators.append('^')
    #future extension --> allow "sub" expressions using parentheses
    if NUM_OPERANDS > 2 and USE_PARENTHESIS == True:
            print("parenthesis")
    #initialize expression by generating a number of given digits
    expression = str(randint(-1*ALLOW_NEGATIVES*(pow(10,NUM_DIGITS)-1), (pow(10,NUM_DIGITS)-1)))

    #generate arithmetic expression by randomly concatenating numbers of given digits and operands
    for i in range(1, NUM_OPERANDS):
        #are negatives allowed?
        y = randint(-1*ALLOW_NEGATIVES*(pow(10,NUM_DIGITS)-1), (pow(10,NUM_DIGITS)-1))
        #random selection of operator
        op = randint(0, len(operators)-1)
        #if the generated number (second operand), a parenthesis is added
        if y>=0:
                expression = expression + operators[op] + str(y)
        else:
                expression = expression + operators[op] + '(' + str(y) + ')'

    #the expression is displayed as a message
    display_message('Compute ' + expression,(160,20))
    inputBox1.input_string=" "
    #screen.blit(inputBox1.get_surface(), (60, 60))
    
    #clock.tick(30)
    game_state = 2
    #return the expression (string) and its value (integer)
    expressionValue = eval(expression)
    #print(expressionValue)
    return expression, eval(expression)
    
#function that places the tiles on the board
#images must be updated according to the player's progress
def updateBoard():
    #global variables that will be modified
    global current_tile
    global current_tile_x
    global current_tile_y
    global future_tiles
    global future_tiles_coords
    global current_offset
    global future_tiles
    global future_tiles_coords
    global potential_next_tile
    global potential_next_tile_x
    global potential_next_tile_y
    global vertical_walls
    global horizontal_walls
    global inputBox1
    #empty future tiles tables    

    inputBox1.clear_text()
    
    
    future_tiles = []
    future_tiles_coords = []
    current_tile_x = current_tile[0]
    current_tile_y = current_tile[1]

    #draw maze on board
    for x in range(ROWS):
            for y in range(COLUMNS):
                #starting tile
                if (x==0 and y==0):
                    screen.blit(image_start, [TILE_MARGIN + y*(TILE_WIDTH + TILE_MARGIN), TOP_MARGIN + TILE_MARGIN + x*(TILE_HEIGHT + TILE_MARGIN)])
                    continue
                #current tile --> different image
                if (x==current_tile_x and y==current_tile_y):
                    #if the current tile is the end --> special case
                    if (x==(ROWS - 1) and y==(COLUMNS - 1)):
                        screen.blit(image_finished, [TILE_MARGIN + y*(TILE_WIDTH + TILE_MARGIN), TOP_MARGIN + TILE_MARGIN + x*(TILE_HEIGHT + TILE_MARGIN)])
                    else:    
                        screen.blit(image_current, [TILE_MARGIN + y*(TILE_WIDTH + TILE_MARGIN), TOP_MARGIN + TILE_MARGIN + x*(TILE_HEIGHT + TILE_MARGIN)])
                    continue
                isFuture = 0    
                #future tiles are within the current tile and the offset and there are no walls in that directionn   
                if (abs(x-current_tile_x)<=current_offset and y==current_tile_y) or (abs(y-current_tile_y)<=current_offset and x==current_tile_x):
                    if (abs(x-current_tile_x)<=current_offset and y==current_tile_y):
                        #if there is no wall in this direction === same y --> horizontal wall
                        #if sum of all walls is 0
                        hsum=0
                        for z in range(x-1,ROWS-1):
                            hsum = hsum + horizontal_walls[z][y]
                        #if no walls --> hsum = 0
                        if hsum == 0:    
                            isFuture = 1    
                    if (abs(y-current_tile_y)<=current_offset and x==current_tile_x):
                    #if there is no wall in this direction === same x --> vertical wall
                        vsum=0
                        for zv in range (0, COLUMNS-1):
                            vsum = vsum + vertical_walls[x][zv]
                        #if no walls --> vsum = 0
                        if vsum == 0:
                            isFuture = 1    

                #future tiles are indicated by an icon    
                if (isFuture==1):
                    screen.blit(image_possible, [TILE_MARGIN + y*(TILE_WIDTH + TILE_MARGIN), TOP_MARGIN + TILE_MARGIN + x*(TILE_HEIGHT + TILE_MARGIN)])
                    future_tiles.append(([TILE_MARGIN + y*(TILE_WIDTH + TILE_MARGIN), TILE_MARGIN + y*(TILE_WIDTH + TILE_MARGIN)+TILE_WIDTH,TOP_MARGIN + TILE_MARGIN + x*(TILE_HEIGHT + TILE_MARGIN),TOP_MARGIN + TILE_MARGIN + x*(TILE_HEIGHT + TILE_MARGIN)+TILE_HEIGHT]))
                    future_tiles_coords.append([x,y])
                    #the current tile is within the offset (0) but not actually a future tile
                    if current_tile in future_tiles_coords:
                        future_tiles_coords.remove(current_tile)
                else:
                    screen.blit(image_future, [TILE_MARGIN + y*(TILE_WIDTH + TILE_MARGIN), TOP_MARGIN + TILE_MARGIN + x*(TILE_HEIGHT + TILE_MARGIN)])
                #special case --> the end
                if (x==(ROWS - 1) and y==(COLUMNS - 1)):
                    screen.blit(image_finish, [TILE_MARGIN + y*(TILE_WIDTH + TILE_MARGIN), TOP_MARGIN + TILE_MARGIN + x*(TILE_HEIGHT + TILE_MARGIN)])
                    #if the finish tile is also a possible next step
                    if len(future_tiles_coords)>0 and x==future_tiles_coords[len(future_tiles_coords)-1][0] and y==future_tiles_coords[len(future_tiles_coords)-1][1]:       
                        screen.blit(image_finishing, [TILE_MARGIN + y*(TILE_WIDTH + TILE_MARGIN) + TILE_MARGIN/2, TOP_MARGIN + TILE_MARGIN + x*(TILE_HEIGHT + TILE_MARGIN)])

    #show walls
    #print('vertical: ',vertical_walls)
    #print('horizontal: ',horizontal_walls)
    
    #vertical walls             
    for x in range(ROWS):
            for y in range(COLUMNS-1):
                if vertical_walls[x][y]==1:
                    #print('vertical x, y ', x,y)
                    screen.blit(image_wall_v, [(y+1)*(TILE_WIDTH+ TILE_MARGIN/2) , TOP_MARGIN + TILE_MARGIN + (x)*(TILE_HEIGHT + TILE_MARGIN)])
                    
                    
    
    #horizontal walls                    
    for x in range(ROWS-1):
            for y in range(COLUMNS-1):
                if horizontal_walls[x][y]==1:
                    screen.blit(image_wall_h, [TILE_MARGIN + (y)*(TILE_WIDTH + TILE_MARGIN), TOP_MARGIN - TILE_MARGIN + (x+1)*(TILE_HEIGHT + TILE_MARGIN)])
                    #screen.blit(image_wall_h, [left, top])
                    
                    

    #Do we need to show an expression for evaluation?
    if showMath:
        #call function to generate expression
        mathExp()
        screen.blit(inputBox1.get_surface(), (60, 60))
    
    
#function that places objects on the initial game board    
def initializeBoard():
    global vertical_walls
    global horizontal_walls
    #split the screen in two areas, one for messages and one for the tiles
    pygame.draw.rect(screen, (200,200,200), [0, 0, SCREEN_WIDTH, TOP_MARGIN])
    pygame.draw.rect(screen, (0,0,0), [0, 100, SCREEN_WIDTH, SCREEN_WIDTH - TOP_MARGIN])
    #initialize array of walls (all are zero = no walls)
    #vertical walls - 1 fewer column - all rows
    vertical_walls = [[0 for x in range(ROWS)] for y in range(COLUMNS-1)]
    #horizontal walls - 1 fewer row - all columns
    horizontal_walls = [[0 for x in range(COLUMNS)] for y in range(ROWS-1)]
    
    #prompt for the player to move using the mouse
        
    display_message('Game started - click on a green tile to move', (160, 20))
    updateBoard()
    
#call initialization function
initializeBoard()

#class for adding buttons
class button():
    def __init__(self, color, x, y, width, height, text=''):
        self.color = color
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.text = text

    def draw(self,win,outline=None):
        #Call this method to draw the button on the screen
        if outline:
            pygame.draw.rect(win, outline, (self.x-2,self.y-2,self.width+4,self.height+4),0)
            
        pygame.draw.rect(win, self.color, (self.x,self.y,self.width,self.height),0)
        bfont = pygame.font.Font('C:\\Ubuntu-R.ttf',16)
        if self.text != '':
            font = pygame.font.SysFont('arial', 16)
            text = font.render(self.text, 1, (0,0,0))
            win.blit(text, (self.x + (self.width/2 - text.get_width()/2), self.y + (self.height/2 - text.get_height()/2)))

    def isOver(self, pos):
        #Pos is the mouse position or a tuple of (x,y) coordinates
        if pos[0] > self.x and pos[0] < self.x + self.width:
            if pos[1] > self.y and pos[1] < self.y + self.height:
                return True
            
        return False

#create a button (not yet displayed)
playAgainButton = button((255,150,150), 300, 20, 100, 30, 'Play Again')

def resetGame():
    #current tile coordinates - current player position
    #initially (0,0)
    current_tile_x = 0
    current_tile_y = 0
    current_tile = (current_tile_x, current_tile_y)

    #offset --> how many blocks can the player move forward
    #offset increases with the number of consecutive correct answers
    current_offset = 1

    #future tiles --> potential next moves according to current tile and offset
    #the future tiles list contains the left - right - top - bottom positions of the potential next moves
    future_tiles = []
    #the future tiles coords list contains the x,y coordinates of the future tiles
    future_tiles_coords = []

    #game in progress
    game_state = 1
    vertical_walls = []
    horizontal_walls = []
    showMath = False


##########

#game loop
while True:
    #game in progress
    #done = False

    #screen.fill((225, 225, 225))
    pygame.draw.rect(screen, (200,200,200), [0, 50, 400, 40])
    #track events on game window
    events = pygame.event.get()
    
    for event in events:
        #the player closed the window end the application
        if event.type == pygame.QUIT:
            pygame.display.quit()
            pygame.quit()
            quit()
            sys.exit()

                
        #the player clicked with the mouse    
        if event.type == pygame.MOUSEBUTTONDOWN:
            #position of click
            mpos = pygame.mouse.get_pos()

            #check if the play again button was clicked
            if playAgainButton.isOver(mpos):
                #print('wants to play again')
                #game_state = 1
                current_tile = (0,0)
                current_tile_x = 0
                current_tile_y = 0
                current_offset = 1
                future_tiles = []
                future_tiles_coords = []
                resetGame()
                initializeBoard()
                inputBox1.clear_text()
                updateBoard()
                game_state = 1
                '''
                print(current_tile)
                print(horizontal_walls)
                print(vertical_walls)
                print(future_tiles)
                print(current_tile)
                '''
            #check if player clicked on future tile and in which
            #if the game is in progresss
            if game_state==1:
                showMath = True
                #calculate current tile coordinates
                current_tile_left = current_tile_y*TILE_WIDTH + TILE_MARGIN
                current_tile_right = current_tile_left + TILE_WIDTH
                current_tile_top = current_tile_x*TILE_HEIGHT + TILE_MARGIN + TOP_MARGIN
                current_tile_bottom = current_tile_top + TILE_HEIGHT

                #for all future tiles
                for k in range(len(future_tiles)):
                    #was there a click on a future tile?
                    if mpos[0]>=future_tiles[k][0] and mpos[0]<=future_tiles[k][1] and mpos[1]>=future_tiles[k][2] and mpos[1]<=future_tiles[k][3]:
                        #check player answer for calculation
                        game_state = 2
                        potential_next_tile = future_tiles_coords[k]
                        potential_next_tile_x = potential_next_tile[0]
                        potential_next_tile_y = potential_next_tile[1]
                        updateBoard()

    #Blit input box surface onto the screen
    if (game_state==2):
        screen.blit(inputBox1.get_surface(), (60, 60))

    #if the user pressed enter in the input box this function returns true and the input is compared to the result of the arithmetic expression
    if inputBox1.update(events):
        #print(inputBox1.get_text())
        #game_state = 1
        if inputBox1.get_text().strip().lstrip('-').isdigit():
            #game_state = 1
            if int(inputBox1.get_text().strip())==expressionValue:
                #inputBox1.text_color = (0, 255, 0)
                inputBox1.input_string="Right! Press enter to clear"
                game_state = 1
                display_message('Correct answer! ',(160,20))
                pygame.display.update()
                #print("correct")
                current_tile = potential_next_tile
                current_tile_x = potential_next_tile_x
                current_tile_y = potential_next_tile_y
                #game_state = 0
                if current_tile[0]==ROWS-1 and current_tile[1]==COLUMNS-1:
                    display_message('You won!!',(160,20))
                    resultsFile = open("results.txt", "a+")
                    resultsFile.write("Win " + str(ROWS) + "x" + str(COLUMNS) + "\r\n")
                    resultsFile.close()
                    showMath = False
                    playAgainButton.draw(screen)
                    screen.blit(image_finished, [TILE_MARGIN + (ROWS-1)*(TILE_WIDTH + TILE_MARGIN), TOP_MARGIN + TILE_MARGIN + (COLUMNS-1)*(TILE_HEIGHT + TILE_MARGIN)])
                    pygame.display.update()
                    #global game_state
                    #game has finished
                    game_state = 0
                #increase current offset
                current_offset = current_offset + 1
                #update game board
                showMath = False
                pygame.display.update()
                updateBoard()
                
            else:
                #inputBox1.text_color = (255, 0, 0)
                game_state = 1
                showMath = False
                inputBox1.input_string="Wrong! Press enter to clear"
                display_message('Wrong answer! ',(160,20))
                pygame.display.update()
                #print("error")
                #the user stays on the same row --> moves column --> vertical wall
                #1st case --> move to the right
                #print('current tile ',current_tile_x,current_tile_y,' potential next',  potential_next_tile_x, potential_next_tile_y)
                if (current_tile_x == potential_next_tile_x):
                    if (current_tile_y < potential_next_tile_y):
                        #print('move right')
                        vertical_walls[current_tile_x][current_tile_y] = 1
                        #screen.blit(image_wall_v, [TILE_MARGIN/2 + (current_tile_x+1)*(TILE_WIDTH), TOP_MARGIN + TILE_MARGIN + (current_tile_y)*(TILE_HEIGHT + TILE_MARGIN)])
                    #move to the left
                    else:
                        #print('move left')
                        vertical_walls[current_tile_x][current_tile_y-1] = 1
                        #screen.blit(image_wall_v, [TILE_MARGIN/2 + (current_tile_x-1)*(TILE_WIDTH), TOP_MARGIN + TILE_MARGIN + (current_tile_y-1)*(TILE_HEIGHT + TILE_MARGIN)])

                #the user stays on the same column --> moves row --> horizontal
                #1st case --> move down
                if (current_tile_y == potential_next_tile_y):
                    if (current_tile_x < potential_next_tile_x):
                        #print('move down')
                        horizontal_walls[current_tile_x][current_tile_y] = 1
                        #screen.blit(image_wall_h, [TILE_MARGIN + (current_tile_x)*(TILE_WIDTH + TILE_MARGIN), TOP_MARGIN + TILE_MARGIN/2 + (current_tile_y+1)*(TILE_HEIGHT)])

                    #move up
                    else:
                        #print('move up')
                        horizontal_walls[current_tile_x - 1][current_tile_y] = 1
                        #screen.blit(image_wall_h, [TILE_MARGIN + (current_tile_x+1)*(TILE_WIDTH + TILE_MARGIN), TOP_MARGIN + TILE_MARGIN/2 + (current_tile_y-1)*(TILE_HEIGHT)])
                
                pygame.display.update()
                updateBoard()
                if (len(future_tiles)==0):
                    display_message('Game over, you lost!',(160,20))
                    showMath = False
                    #record loss in results file
                    #print("Loss " + str(ROWS) + " " + str(COLUMNS) + "\r\n")
                    resultsFile = open("results.txt", "a+")
                    resultsFile.write("Loss " + str(ROWS) + "x" + str(COLUMNS) + "\r\n")
                    resultsFile.close()
                    playAgainButton.draw(screen)
                    pygame.display.update()
                    game_state = 0
            
        else:
            game_state = 2
            inputBox1.clear_text()
                
    pygame.display.update()
